class Block:
    def __init__(self, valid, tag, next):
        self.tag = tag
        self.valid = valid
        self.next = next

